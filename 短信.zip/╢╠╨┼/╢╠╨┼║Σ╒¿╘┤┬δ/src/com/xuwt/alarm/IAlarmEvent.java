package com.xuwt.alarm;


/**
 * 
* @Description: 事件响应接口类
* @author xuwt
* @date 2013年12月3日 下午4:32:47
* @version V1.0
 */
public interface IAlarmEvent{
	void onTimeEvent();
}
